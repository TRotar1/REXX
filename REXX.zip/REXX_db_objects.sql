CREATE TABLE IF NOT EXISTS employee 
(id INT NOT NULL AUTO_INCREMENT, 
name VARCHAR(800), 
email VARCHAR(800) NOT NULL UNIQUE, 
PRIMARY KEY(id));

CREATE TABLE IF NOT EXISTS event (
id INT NOT NULL UNIQUE, 
name VARCHAR(800), 
PRIMARY KEY(id)
);

CREATE TABLE IF NOT EXISTS employee_event
(id INT NOT NULL AUTO_INCREMENT, 
partid INT not null,
evenid INT NOT NULL, 
emplid INT NOT NULL, 
date datetime, 
vers VARCHAR(40),
fee DECIMAL(20, 6), 
PRIMARY KEY(id),
FOREIGN KEY (evenid) REFERENCES event(id),
FOREIGN KEY (emplid) REFERENCES employee(id), 
UNIQUE KEY `index_01`(`evenid`, `emplid`));
             

CREATE OR REPLACE VIEW employee_event_v AS
select 
t.id as employee_id,
t.name as employee_name,
t.email as employee_email,
e.id as event_id,
e.name AS event_name,
ee.id as empeve_id,
ee.date as eveemp_date,
ee.vers as eveemp_vers,
ee.fee as eveemp_fee
from employee t
Left Join employee_event ee ON ee.emplid = t.id
Left Join event e ON e.id = ee.evenid
order by t.id;