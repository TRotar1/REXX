<script type="text/javascript">
	var $employeeFilter = '';
	var $eventFilter = '';

	function employeeSelectFunction($sel) {
		$employeeFilter =$sel.options[$sel.selectedIndex].value;
	}
	function eventSelectFunction($sel) {
		$eventFilter =$sel.options[$sel.selectedIndex].value;
	}
	
	function buttonFilterFunction() {
		table = document.getElementById("emp_event");
		tr = table.getElementsByTagName("tr");
		
	for (i = 0; i < tr.length; i++) {
	   td_employee_id = tr[i].getElementsByTagName("td")[0];
	   td_event_id = tr[i].getElementsByTagName("td")[3];
	   td_event_date = tr[i].getElementsByTagName("td")[5];
	   
	   dateFilter = document.getElementById("date").value;
			
			
			
	    if (td_employee_id || td_event_id || td_event_date) {
	      employee_id = td_employee_id.textContent || td_employee_id.innerText;
	      event_id = td_event_id.textContent || td_event_id.innerText;
	      event_date = td_event_date.textContent || td_event_date.innerText;
	      event_date = event_date.substring(0, 10);
				
	      	
	      if (($employeeFilter.length == 0 || employee_id == $employeeFilter) 
	      	&& ($eventFilter.length == 0 || event_id == $eventFilter) 
	      	&& (dateFilter.length == 0 || event_date == dateFilter )) {
	        tr[i].style.display = "";
	      } else {
	        tr[i].style.display = "none";
	      }
	    }
	  }
		calculateSum();
	};

	function calculateSum() {
		table = document.getElementById("emp_event");
		
		suminput = document.getElementById("td-sum");

		let sum = 0;
		for (i = 0; i < tr.length; i++) {	
   		td_fee = tr[i].getElementsByTagName("td")[6];
   
   		if(td_fee != undefined && tr[i].style.display == '')
   	sum += parseFloat(td_fee.innerText);
	  }

  suminput.innerHTML  = sum;
	 };

</script>