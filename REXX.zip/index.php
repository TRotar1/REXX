<?php include_once("employee_events.php") ?>
<?php include_once("employee_events.js") ?>
<html>
	<head>
		<link rel="stylesheet" href="employee_events.css">
		<title>Import JSON File</title>
	</head>
	<body>
		<form method="post" enctype="multipart/form-data">
			JSON File <input type="file" name="jsonFile">
			<br><br>
			<input type="submit" value="Import" name="buttonImport">
		</form>
	</body>

<label for="employees">Choose employee:</label>


	
<select id=employees name="employees" onChange="employeeSelectFunction(this);">	
	<?php
	if(isset($employee_array))
  	foreach($employee_array as $row)
		{ ?>
				<?php echo "<option value=" . $row['id'] . ">" . $row['name'] . "</option>";; ?>
		<?php } ?>
	</select>
	<br><br>
	
	<label for="events">Choose event:</label>
	<select id=events name="events" onChange="eventSelectFunction(this);">	
	<?php
	if(isset($event_array))
  	foreach($event_array as $row)
		{ 
				echo "<option value=" . $row['id'] . ">" . $row['name'] . "</option>";
		 } ?>
	</select>
	<br><br>
		<label for="date">Date of event:</label>
		<input type="date" id="date" name="date"/>
		
		<button type="button" id="filter-button" onclick="buttonFilterFunction()">Filter</button>
<br><br>
<table id="emp_event" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>               
							<thead>
							<tr>
								<th>Employee name</th>
								<th>eMail</th>
								<th>Assigned course</th>
								<th>Date of course</th>
								<th>Fee</th>
							</tr>
							</thead>
            </tr>
        </thead>
        <tbody>
            <?php
            if(isset($event_employee_array))
            		foreach($event_employee_array as $row)
							{ ?>
								<tr>
									<td style="display:none;"><?php echo $row['employee_id']; ?></td>
									<td><?php echo $row['employee_name']; ?></td>
	                <td><?php echo $row['employee_email']; ?></td>
	                <td style="display:none;"><?php echo $row['event_id']; ?></td>
	                <td><?php echo $row['event_name']; ?></td>
	                <td><?php echo $row['eveemp_date']; ?></td>
	                <td align = "right"><?php echo $row['eveemp_fee']; ?></td>
                </tr>
							<?php } ?>
       </tbody>
</table>

<table id="table-sum" class="display" cellspacing="0" width="100%">
	<tr>
		<td id = "td-sum" align = "right">	
			<?php
			if(isset($event_employee_array)) {
				$sum = 0;
        foreach($event_employee_array as $row)
				{ 
	         $sum = $sum + $row['eveemp_fee'];
				} 
				echo $sum;
			}
			?>
		</td>
	</tr>
</table>
</html>